package com.example.fapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
